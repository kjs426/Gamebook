from django.apps import AppConfig


class NotesConfig(AppConfig):
    name = 'notes'
